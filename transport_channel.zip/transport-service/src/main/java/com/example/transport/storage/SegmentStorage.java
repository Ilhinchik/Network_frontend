package com.example.transport.storage;

import com.example.transport.dto.SegmentDTO;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class SegmentStorage {

    private final Map<String, MessageContainer> storage = new ConcurrentHashMap<>();

    // Генерация составного ключа по sendTime и username
    private String generateKey(String sendTime, String username) {
        // Если sendTime уже начинается с username, возвращаем его как есть:
        if (sendTime.startsWith(username + "_")) {
            return sendTime;
        }
        return username + "_" + sendTime;
    }


    public void addSegment(SegmentDTO segment) {
        String key = generateKey(segment.getSendTime(), segment.getUsername());
        storage.compute(key, (k, message) -> {
            if (message == null) {
                message = new MessageContainer(segment.getTotalSegments(), segment.getUsername());
            }
            message.addSegment(segment.getSegmentNumber(), segment.getPayload());
            return message;
        });
    }

    public Map<String, MessageContainer> getStorage() {
        return storage;
    }

    public void removeMessage(String sendTime, String username) {
        String key = generateKey(sendTime, username);
        System.out.println(">>> removeMessage called with key: " + key);
        int before = storage.size();
        storage.remove(key);
        int after = storage.size();
        System.out.println(">>> Storage size changed from " + before + " to " + after);
    }
}
