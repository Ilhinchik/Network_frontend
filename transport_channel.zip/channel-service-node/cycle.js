class Cycle {
    constructor() {
        this.generator = "10011"; // Порождающий полином [15,11]
    }

    static coding(bitStr) {
        const instance = new Cycle(); // создаём объект для доступа к generator
        bitStr += "0000"; // Добавляем 4 нуля для CRC
        const remainder = instance.moduloDivision(bitStr);
        const codeword = bitStr.slice(0, -4) + remainder;
        return codeword;
    }

    static decoding(codeword) {
        const instance = new Cycle();
        const remainder = instance.moduloDivision(codeword);

        if (parseInt(remainder, 2) === 0) {
            return codeword.slice(0, -4);
        } else {
            // Можно добавить алгоритм исправления ошибок
            return codeword.slice(0, -4);
        }
    }

    moduloDivision(dividend) {
        let remainder = dividend.slice(0, this.generator.length);

        for (let i = this.generator.length; i <= dividend.length; i++) {
            if (remainder[0] === '1') {
                remainder = this.xor(remainder, this.generator);
            } else {
                remainder = this.xor(remainder, '0'.repeat(this.generator.length));
            }

            if (i < dividend.length) {
                remainder = remainder.slice(1) + dividend[i];
            } else {
                remainder = remainder.slice(1);
            }
        }

        return remainder.padStart(this.generator.length - 1, '0');
    }

    xor(a, b) {
        let result = '';
        for (let i = 0; i < a.length; i++) {
            result += a[i] === b[i] ? '0' : '1';
        }
        return result;
    }
}

module.exports = { Cycle };