const express = require('express');
const bodyParser = require('body-parser');
const { Cycle } = require('./cycle');
const axios = require('axios');

// создаём express приложение
const app = express();
app.use(bodyParser.json());

// конфиг
const PORT = 8000;
const TRANSPORT_URL = 'http://transport-service:8080/transfer';

const CHANCE_OF_ERROR = 0.0; // для теста лучше отключить 0.1
const CHANCE_OF_LOSS = 0.0;  // для теста лучше отключить  0.02

app.post('/code', async (req, res) => {
    const segment = req.body;
    console.log('Received segment:', segment);

    const dataStr = JSON.stringify(segment);
    const bitStr = toBitString(dataStr);

    const chunks = chunkString(bitStr, 11);
    const codedChunks = chunks.map(Cycle.coding);

    const erroredChunks = codedChunks.map(chunk => {
        if (Math.random() < CHANCE_OF_ERROR) {
            const index = Math.floor(Math.random() * chunk.length);
            const flipped = chunk[index] === '1' ? '0' : '1';
            return chunk.slice(0, index) + flipped + chunk.slice(index + 1);
        }
        return chunk;
    });

    if (Math.random() < CHANCE_OF_LOSS) {
        console.log('Segment lost during transmission!');
        return res.status(200).send({ message: 'Segment lost (simulated).' });
    }

    const decodedChunks = erroredChunks.map(Cycle.decoding);
    console.log('Decoded chunks:', decodedChunks);

    const decodedBitStr = decodedChunks.join('');
    console.log('Decoded bit string:', decodedBitStr);

    const decodedBytes = bitStringToBytes(decodedBitStr);
    console.log('Decoded bytes:', decodedBytes);

    if (!decodedBytes || decodedBytes.length === 0) {
        console.error('Decoded bytes is empty!');
        return res.status(500).send({ error: 'Decoded bytes empty!' });
    }

    try {
        const decodedJSON = JSON.parse(decodedBytes);
        console.log('Decoded JSON ready for sending:', decodedJSON);

        const response = await axios.post(TRANSPORT_URL, decodedJSON);
        console.log('Transport level response:', response.status);

        res.status(200).send({ message: 'Segment processed and sent back.' });
    } catch (err) {
        console.error('Failed to decode or send:', err.message);
        res.status(500).send({ error: 'Decoding failed.' });
    }
});

// запускаем сервер
app.listen(PORT, () => {
    console.log(`Channel level service running on http://localhost:${PORT}`);
});


function toBitString(str) {
    return [...Buffer.from(str)].map(byte => byte.toString(2).padStart(8, '0')).join('');
}

function bitStringToBytes(bitStr) {
    const bytes = [];
    for (let i = 0; i < bitStr.length; i += 8) {
        const byte = bitStr.slice(i, i + 8);
        if (byte.length === 8) {
            bytes.push(parseInt(byte, 2));
        }
    }
    return Buffer.from(bytes).toString();
}

function chunkString(str, length) {
    return str.match(new RegExp('.{1,' + length + '}', 'g')) || [];
}